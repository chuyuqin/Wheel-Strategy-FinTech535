# PG Wheel Strategy

FINTECH 535 · Chuyu Qin · November 1, 2026

The submission website is `docs/index.html`. The full PG study covers January 3, 2023–September 30, 2024. Starting capital is $50,000 per account. The wheel returned 22.51% versus 19.27% for PG buy-and-hold with dividend reinvestment. Maximum drawdowns were -7.51% and -10.66%.

The website includes the thesis, three trading rules, one completed cycle, exact daily holdings, searchable blotter, ledger, dividend accounting, execution evidence and research-selection disclosures. PG was selected after a four-stock comparison; the result is exploratory. The January–September 2024 restart favors buy-and-hold. The common window was limited by cached option coverage after the daily LSEG download cap; no longer cross-stock result is claimed.

## View and publish

Open `docs/index.html` directly, or run `python3 -m http.server 8000 --directory docs`. Publish the `main` branch, `/docs` directory with GitHub Pages. All charts and data are bundled; viewing requires no LSEG access. Publication is left to the repository owner.

## Reproduce from the original private cache

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python src/normalize_comparison_cache.py
.venv/bin/python src/compare_stocks.py
.venv/bin/python src/verify_comparison.py
.venv/bin/python src/build_site.py
```

Raw responses in `data/raw/` are ignored by Git and excluded from the ZIP. Fetching history requires an entitled LSEG Workspace session. `src/fetch_comparison.py` checks the remaining allowance and can resume completed caches after the provider resets its quota. Fresh historical observations may differ after vendor revisions.

## Records

`docs/results/comparison/PG/historical/` contains the main daily ledger, blotter, benchmark records, metrics, skipped decisions and dividend-assignment scenario. `PG/test/` contains the separate January–September 2024 restart diagnostic; the internal folder name is not a claim of an unseen holdout. The original frozen AMZN settings were transferred to PG without name-specific retuning.

`comparison.html` preserves all four comparison stocks. `amzn-study.html` preserves the longer original AMZN report. The comparison plan versions, input audits, source manifest and verification results are under `docs/results/`. The main accounting identities, fill proxies and remaining biases are explained in the website. Synthetic fixtures test accounting only and never enter performance.
